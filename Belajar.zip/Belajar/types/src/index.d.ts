import ARnft from "./ARnft";
declare const _default: {
    ARnft: typeof ARnft;
};
export default _default;
